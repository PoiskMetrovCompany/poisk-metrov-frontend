<?php if(isset($valueToCheck)): ?>
    <?php if($valueToCheck != '' && $valueToCheck != 0 && $valueToCheck != null): ?>
        <div class="plan-card description"><?php echo e($text); ?></div>
    <?php endif; ?>
<?php else: ?>
    <div class="plan-card description"><?php echo e($text); ?></div>
<?php endif; ?><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/cards/plan/description-line.blade.php ENDPATH**/ ?>