<div id="<?php echo e($id); ?>" class="arrow-buttons-container <?php echo e($spaced ?? ''); ?>" >
    <?php echo $__env->make('buttons.arrow-left', ['isGrey' => $spaced ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('buttons.arrow-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/arrow-buttons-container.blade.php ENDPATH**/ ?>