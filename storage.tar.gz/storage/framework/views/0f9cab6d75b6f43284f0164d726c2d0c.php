<user-menu>
    <header>
        <div>
            <?php echo $__env->make('custom-elements.parts.profile-placeholder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div>
            <?php if(auth()->guard()->check()): ?>
                <h6>Агент</h6>
                <h5><?php echo e($user->name); ?> <?php echo e($user->surname); ?></h5>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <h5>Посетитель</h5>
            <?php endif; ?>
        </div>
        <button>
            <?php echo $__env->make('icons.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    </header>
    <div>
        <?php echo $__env->make('custom-elements.contained-checkbox', [
            'id' => 'agents-options-toggle',
            'placeholder' => 'Работа с клиентом',
            'subclass' => 'toggle',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <ul>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Мои заявки',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Тарифная сетка',
            'href' => '/',
            'clientOnly' => true,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Мои презентации',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Бронирование',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Ипотека',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Подбор',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Сравнение',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'settings',
            'optionText' => 'Настройки профиля',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('custom-elements.parts.user-menu-option', [
            'icon' => 'exit',
            'optionText' => 'Выйти из личного кабинета',
            'href' => '/',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
</user-menu>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/user-menu.blade.php ENDPATH**/ ?>