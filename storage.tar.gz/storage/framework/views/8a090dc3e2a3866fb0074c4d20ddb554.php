<div id="<?php echo e($id); ?>" class="filter base-container">
    <span><?php echo e($title); ?></span>
    <?php echo $__env->make('dropdown.elements.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('icons.filter-arrow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make($optionsTemplate, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/primary-dropdown.blade.php ENDPATH**/ ?>