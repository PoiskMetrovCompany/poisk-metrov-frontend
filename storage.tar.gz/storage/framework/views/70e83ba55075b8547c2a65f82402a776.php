<button id="open-chat-button" class="common-button round-button">
    <?php echo $__env->make('icons.chat.button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</button>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/open-button.blade.php ENDPATH**/ ?>