<button type="button" <?php if(isset($buttonId)): ?> id="<?php echo e($buttonId); ?>" <?php endif; ?> class="common-button <?php echo e($subclass ?? ''); ?>">
    <?php if(isset($buttonIcon)): ?>
        <div class="icon d24x24 <?php echo e($buttonIcon); ?> white"> </div>
    <?php endif; ?>
    <?php echo e($buttonText); ?>

</button>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/buttons/common.blade.php ENDPATH**/ ?>