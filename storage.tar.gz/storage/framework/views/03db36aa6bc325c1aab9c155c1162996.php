<?php
    $chatEnabled = boolval(config('app.chat_enabled'));
?>

<?php if($chatEnabled): ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/pusher.js'); ?>
<?php endif; ?><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/scripts/pusher.blade.php ENDPATH**/ ?>