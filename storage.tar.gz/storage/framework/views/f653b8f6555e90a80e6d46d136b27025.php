<div class="input-container">
    <fieldset class="input-fieldset">
        <legend class="input-legend"><?php echo e($nameInputTitle ?? 'Ваша фамилия'); ?><span
                class="red-highlight"><?php echo e($required ?? ''); ?></span></legend>
        <div class="input-wrapper">
            <input class="input-text <?php echo e($style ?? ''); ?>" type="text" id="last_name" name="last_name" required
                   placeholder=<?php echo $placeholder ?? 'Введите&nbsp;вашу&nbsp;фамилию'; ?>

                <?php if(isset($user) && !isset($nameInputTitle)): ?> value="<?php echo e($value ?? $user->name); ?>"
                   <?php else: ?> value="<?php echo e($value ?? ''); ?>" <?php endif; ?>>
            <img src="<?php echo e(Vite::asset('resources/assets/content/content-error.svg')); ?>" class="error-icon">
            <div class="icon action-close d20x20 grey3"></div>
        </div>
    </fieldset>
    <div class="input-error" id="input-error">Заполните поле корректно</div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/inputs/last-name.blade.php ENDPATH**/ ?>