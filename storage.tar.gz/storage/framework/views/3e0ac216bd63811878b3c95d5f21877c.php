<button>
    <?php if(isset($icon)): ?>
        <?php echo $__env->make('icons.icon', ['iconClass' => $icon, 'iconColor' => 'orange'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <div type="text"><?php echo e($text); ?></div>
</button>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/parts/share-menu-item.blade.php ENDPATH**/ ?>