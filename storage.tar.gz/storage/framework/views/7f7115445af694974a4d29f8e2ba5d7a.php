<div id="title-with-pic" class="main-page-title title-cards">
    <?php echo $__env->make('home-page.cards.title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('home-page.cards.mortgage-timer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('home-page.cards.learn-about-first-sale', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/top-cards.blade.php ENDPATH**/ ?>