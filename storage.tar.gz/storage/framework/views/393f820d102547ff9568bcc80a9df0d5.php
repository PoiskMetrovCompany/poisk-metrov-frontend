<?php $__currentLoopData = $searchData->builders->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('dropdown.names.search-item', [
        'item' => $item,
        'context' => 'Застройщик',
        'icon' => 'search-builder',
        'field' => $searchData->builders->field,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/list/builder.blade.php ENDPATH**/ ?>