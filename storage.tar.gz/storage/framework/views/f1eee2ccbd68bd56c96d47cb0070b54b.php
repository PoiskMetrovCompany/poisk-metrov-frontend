<div class="filter type-specific-filters">
    <?php echo $__env->make('search.type-specific-filter', [
        'id' => 'filter-district',
        'icon' => 'search-location',
        'previewName' => 'Район',
        'searchDataPart' => $searchData->districts,
        'dropdownId' => 'filter-district-dropdown',
        'dropdownContext' => 'Район',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('search.type-specific-filter', [
        'id' => 'filter-builder',
        'icon' => 'search-builder',
        'previewName' => 'Застройщик',
        'searchDataPart' => $searchData->builders,
        'dropdownId' => 'filter-builder-dropdown',
        'dropdownContext' => 'Застройщик',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('search.type-specific-filter', [
        'id' => 'filter-building',
        'icon' => 'search-building',
        'previewName' => 'ЖК',
        'searchDataPart' => $searchData->names,
        'dropdownId' => 'filter-building-dropdown',
        'dropdownContext' => 'ЖК',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('search.type-specific-filter', [
        'id' => 'filter-street',
        'icon' => 'search-street',
        'previewName' => 'Улица',
        'searchDataPart' => $searchData->addresses,
        'dropdownId' => 'filter-street-dropdown',
        'dropdownContext' => 'Улица',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('search.type-specific-filter', [
        'id' => 'filter-metro',
        'icon' => 'search-metro',
        'previewName' => 'Метро',
        'searchDataPart' => $searchData->stations,
        'dropdownId' => 'filter-metro-dropdown',
        'dropdownContext' => 'Метро',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/type-specific-searches.blade.php ENDPATH**/ ?>