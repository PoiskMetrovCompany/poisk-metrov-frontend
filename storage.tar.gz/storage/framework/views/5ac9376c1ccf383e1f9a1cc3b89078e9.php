<div class="header links-container">
    <?php echo $__env->make('header.big-link', ['link' => 'catalogue', 'text' => 'Каталог недвижимости'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('header.big-link', ['link' => 'sell', 'text' => 'Продать'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('header.big-link', ['link' => 'mortgage', 'text' => 'Ипотека'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/links.blade.php ENDPATH**/ ?>