<div>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/quiz/loader.js'); ?>
    <div id="quiz-section" class="quiz base-container">
        <?php echo $__env->make('quiz.step', [
            'quizTitleHtml' => 'КАКОЙ <span>ЕЖЕМЕСЯЧНЫЙ</br>ПЛАТЁЖ</span> ПО ИПОТЕКЕ</br>ВАМ ПОДОЙДЁТ?',
            'buttonTexts' => [
                'До 30 тыс. ₽',
                'До 50 тыс. ₽',
                'До 70 тыс. ₽',
                'До 100 тыс. ₽',
                'Больше 100 тыс. ₽',
            ],
            'isVisible' => true,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('quiz.step', [
            'quizTitleHtml' => 'КАКОЙ БУДЕТ</br> <span>ПЕРВОНАЧАЛЬНЫЙ</br>ВЗНОС?</span>',
            'buttonTexts' => [
                'Не знаю',
                'Без взноса',
                'До 1 млн. ₽',
                'До 3 млн. ₽',
                'До 5 млн. ₽',
                'Более 5 млн. ₽',
            ],
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('quiz.step', [
            'quizTitleHtml' => '<span>СКОЛЬКО КОМНАТ</span></br>БУДЕТ В КВАРТИРЕ?</br>',
            'buttonTexts' => ['Студия', '1 комната', '2 комнаты', '3 комнаты', '4+ комнаты'],
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('quiz.step', [
            'quizTitleHtml' => '<span>ОСТАВЬТЕ НОМЕР,</span></br>МЫ БЕСПЛАТНО</br>НАЙДЕМ ВАМ КВАРТИРУ',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/quiz/container.blade.php ENDPATH**/ ?>