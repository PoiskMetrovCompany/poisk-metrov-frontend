<div class="sub-menus background" id="get-free-catalogue-popup">
    <form autocomplete="off" id="get-free-catalogue-form" class="sub-menus card">
        <div class="sub-menus form">
            <?php echo csrf_field(); ?>
            <div class="sub-menus top-half">
                <div class="sub-menus top">
                    <div class="sub-menus header">
                        <div class="sub-menus title">
                            <?php if($selectedCity == 'novosibirsk'): ?>
                                Скачать каталог новостроек Новосибирска
                            <?php endif; ?>
                            <?php if($selectedCity == 'st-petersburg'): ?>
                                Скачать каталог новостроек Санкт-Петербурга
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="sub-menus close">
                        <div class="icon action-close d16x16 orange"></div>
                    </div>
                </div>
                <div class="sub-menus description">
                    Оставьте номер телефона и мы отправим каталог вам на мессенджер
                </div>
            </div>
            <?php echo $__env->make('inputs.phone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="get-free-catalogue where-send-grid">
                <div class="get-free-catalogue where-send-title">Куда отправить?</div>
                <div id="get-catalogue-buttons" class="document-download grey-container menu">
                    <div class="tab enabled" data-name="WhatsApp">
                        <div class="document-download with-icon">
                            WhatsApp
                            <div class="icon whatsapp d16x16 disabled"></div>
                        </div>
                    </div>
                    <div class="tab disabled" data-name="Telegram">
                        <div class="document-download with-icon">
                            Telegram
                            <div class="icon telegram d16x16 disabled"></div>
                        </div>
                    </div>
                    <div class="tab disabled" data-name="Скачать на сайте" style="display: none">
                        <div class="document-download with-icon">
                            Скачать на сайте
                            <div class="icon phone d16x16 disabled" style="display: none"></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('common.personal-info-agreement', [
                'buttonText' => 'Получить&nbsp;каталог',
                'type' => 'modal',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </form>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/menus/forms/download-catalogue.blade.php ENDPATH**/ ?>