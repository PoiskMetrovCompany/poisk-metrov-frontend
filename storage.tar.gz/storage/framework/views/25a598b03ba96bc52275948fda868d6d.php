<div class="auth-popup header">
    <div class="auth-popup title">
        Личный кабинет
    </div>
    <div class="auth-popup close">
        <div class="icon action-close"></div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/authorization/popup-header.blade.php ENDPATH**/ ?>