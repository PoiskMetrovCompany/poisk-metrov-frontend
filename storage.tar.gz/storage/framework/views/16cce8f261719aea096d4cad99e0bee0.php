<?php
    $chatEnabled = boolval(config('app.chat_enabled'));
?>

<div class="window-bottom-buttons-container">
    <?php if($chatEnabled): ?>
        <?php echo $__env->make('chat.open-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('common.up-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/bottom-buttons.blade.php ENDPATH**/ ?>