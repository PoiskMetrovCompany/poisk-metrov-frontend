<div class="peinag base-container">
    <input type="submit" value=<?php echo $buttonText ?? 'Отправить'; ?> class="peinag button <?php echo $type ?? ''; ?>">
    <?php echo $__env->make('common.you-agree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/personal-info-agreement.blade.php ENDPATH**/ ?>