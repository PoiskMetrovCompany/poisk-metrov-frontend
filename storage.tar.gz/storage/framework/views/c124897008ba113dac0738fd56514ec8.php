<div class="icon <?php echo e($iconClass); ?> 
<?php if(isset($iconColor)): ?>
<?php echo e($iconColor); ?>

<?php endif; ?>"></div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/icons/icon.blade.php ENDPATH**/ ?>