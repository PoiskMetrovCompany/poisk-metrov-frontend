<link rel="stylesheet" href="https://cdn.envybox.io/widget/cbk.css">
<?php if(App::isProduction()): ?>
    <script type="text/javascript" src="https://cdn.envybox.io/widget/cbk.js?wcb_code=84dc92dbb599487768f4667ea945160f"
        charset="UTF-8" async></script>
<?php else: ?>
    <script type="text/javascript" src="https://cdn.envybox.io/widget/cbk.js?wcb_code=78cf312c0fcfae9f26d229f2a5a07d44"
        charset="UTF-8" async></script>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/scripts/crm-chat.blade.php ENDPATH**/ ?>