<?php
    $cityPartners['novosibirsk'] = [
        'rastsvetay',
        'meta',
        'energo-montazh',
        'acacia',
        'elka',
        'brusnika',
        'scandia',
        'vira-stroy',
        'yasniy-bereg',
        'dom-stroy',
        'kpd-gazstroy',
        'soyuz',
        'noviy-mir',
    ];
    $cityPartners['st-petersburg'] = [
        'akvilon',
        'arsenal',
        'cdc',
        'fsk',
        'glorax',
        'kvs',
        'lcp',
        'pik',
        'lenstroy',
        'polis',
        'rbi',
        'setl',
        'terminal',
    ];
?>

<?php if(key_exists($selectedCity, $cityPartners)): ?>
    <div class="base-container">
        <div class="title">
            Партнёры, которые нам <span class="link-highlight">доверяют</span>
        </div>
        <div class="partners grid" id="partners-grid-novosibirsk"
            style="display: <?php echo e($selectedCity == 'novosibirsk' ? 'grid' : 'none'); ?>">
            <?php $__currentLoopData = $cityPartners['novosibirsk']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="partners partner-card">
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['partner-icons-novosibirsk ' . $item . ' bg']); ?>"></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="partners grid" id="partners-grid-st-petersburg"
            style="display: <?php echo e($selectedCity == 'st-petersburg' ? 'grid' : 'none'); ?>">
            <?php $__currentLoopData = $cityPartners['st-petersburg']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="partners partner-card">
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['partner-icons-st-petersburg ' . $item . ' bg']); ?>"></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/partners.blade.php ENDPATH**/ ?>