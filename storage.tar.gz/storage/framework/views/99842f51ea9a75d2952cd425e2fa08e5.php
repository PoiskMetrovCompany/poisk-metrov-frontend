<div id="thanks-for-contacts" class="thanks-for-contacts background">
    <div class="thanks-for-contacts card">
        <div class="thanks-for-contacts title">
        <div class="thanks-for-contacts success">Ваше сообщение успешно отправлено!</div>
        <div class="thanks-for-contacts failure header">
            <div class="thanks-for-contacts error">
                <div class="thanks-for-contacts error-icon">
                    <div class="icon action-close d20x20 white"></div>
                </div>
                Ошибка
            </div>
        </div>
        <div class="thanks-for-contacts close">
            <div class="icon action-close d16x16 orange"></div>
        </div>
        </div>
        <div class="thanks-for-contacts failure">
            Произошла ошибка, обновите страницу позднее
        </div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/popups/thanks-for-contacts.blade.php ENDPATH**/ ?>