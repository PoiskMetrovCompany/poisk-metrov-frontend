<div class="footer contacts info copyright">
    <a href="/policy">Политика обработки персональных данных</a>
    <div>
        <?php
            $year = date('Y');
        ?>
        © 2019-<?php echo e($year); ?> Поиск метров. Все права защищены.
    </div>
</div><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/copyright.blade.php ENDPATH**/ ?>