<form id="call-for-apartments" class="chat-call base-container" autocomplete="off">
    <?php echo $__env->make('inputs.name', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inputs.phone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('common.personal-info-agreement', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/call-for-apartment.blade.php ENDPATH**/ ?>