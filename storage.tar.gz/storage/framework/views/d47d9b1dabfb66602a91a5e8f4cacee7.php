<div class="names-dropdown close-button">
    <div class="icon arrow-down"></div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/close-button.blade.php ENDPATH**/ ?>