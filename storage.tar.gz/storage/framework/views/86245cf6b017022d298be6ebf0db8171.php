<?php echo $__env->make('filters.buttons-grid', [
    'id' => 'years-buttons',
    'buttonsTitle' => 'Срок сдачи',
    'containerClass' => 'filter-toggles buttons-container',
    'elements' => $searchData->dropdownData->years,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/filters/buttons/years.blade.php ENDPATH**/ ?>