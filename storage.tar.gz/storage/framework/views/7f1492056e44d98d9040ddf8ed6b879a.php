<div class="names-dropdown button" context="<?php echo e($buttonText); ?>">
    <?php echo e($buttonText); ?>

    <span class="filter counter">0</span>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/category-button.blade.php ENDPATH**/ ?>