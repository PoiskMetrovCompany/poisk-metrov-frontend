<a id="current-city-button" href="javascript:void(0)" class="header small-city-selection">
    <?php echo $__env->make('icons.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div><?php echo e($cityName); ?></div>
    <?php echo $__env->make('icons.filter-arrow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/city-selection.blade.php ENDPATH**/ ?>