<div id="login-form-phone-popup" class="auth-popup background">
    <div class="auth-popup base-container">
        <?php echo $__env->make('authorization.popup-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form autocomplete="off" id="login-form-phone" class="auth-popup form">
            <?php echo csrf_field(); ?>
            <div class="login text-container">
                <div>
                    Войдите в личный кабинет, чтобы получить доступ ко всем возможностям.
                </div>
                <div>
                    У нас нет паролей - вход осуществляется по номеру телефона, на который мы звоним.
                </div>
            </div>
            <?php echo $__env->make('inputs.phone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <input type="submit" class="peinag button" value="Получить код">
            <div class="peinag container">
                <div class="peinag checkbox-borders">
                    <input name="consent-checkbox" type="checkbox" class="peinag checkbox" required>
                </div>
                <div class="peinag description">
                    Нажимая на кнопку, вы даете согласие на обработку<a href="/policy">своих персональных данных</a>
                    и согласие на получение<a href="/ads-agreement">рекламных рассылок</a>.
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/authorization/authorize-popup.blade.php ENDPATH**/ ?>