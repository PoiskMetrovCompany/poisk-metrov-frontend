<div class="arrow-button">
    <div class="icon arrow-left p50x50 disabled"></div>
</div><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/buttons/arrow-left.blade.php ENDPATH**/ ?>