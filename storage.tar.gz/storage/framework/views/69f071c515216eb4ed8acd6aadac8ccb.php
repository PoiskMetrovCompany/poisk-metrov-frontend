<div class="header small-links">
    <a href="/about-us">О компании</a>
    <a href="/for-partners">Партнёрам</a>
    <a href="/offices">Офисы</a>
</div><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/small-links.blade.php ENDPATH**/ ?>