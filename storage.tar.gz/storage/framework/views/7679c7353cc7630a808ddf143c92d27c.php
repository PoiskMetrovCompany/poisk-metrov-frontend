
<?php if(auth()->guard()->check()): ?>
    <script>
        const isUserAuthorized = true;
    </script>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>
    <script>
        const isUserAuthorized = false;
    </script>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/scripts/user-auth-js-variable.blade.php ENDPATH**/ ?>