<a href="<?php echo e($link ?? 'javascript:void(0)'); ?>" selected="<?php echo e(var_export($isCurrentPage)); ?>"
    <?php if(isset($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?>>
    <?php echo $__env->make('icons.icon', ['iconClass' => $icon, 'iconColor' => 'grey5'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div><?php echo e($title); ?></div>
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/shared/toolbar/button.blade.php ENDPATH**/ ?>