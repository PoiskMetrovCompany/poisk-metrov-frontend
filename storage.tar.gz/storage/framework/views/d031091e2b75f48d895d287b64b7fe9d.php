<?php echo $__env->make('search.primary-dropdown', [
    'id' => 'filter-price',
    'title' => 'Цена',
    'hideCounter' => 'true',
    'options' => $searchData->dropdownData->prices,
    'optionsTemplate' => 'dropdown.options.compare',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/dropdown/price.blade.php ENDPATH**/ ?>