searchid="<?php echo e($item->searchid); ?>" condition="=" displayName="<?php echo e($item->name); ?>"
value="<?php echo e($item->name); ?>" field=<?php echo e($field); ?> context=<?php echo e($context); ?>

<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/copy-name-attributes.blade.php ENDPATH**/ ?>