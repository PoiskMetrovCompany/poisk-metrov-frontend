<button type="button" class="chat-window close">
    <?php echo $__env->make('icons.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</button>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/button/close.blade.php ENDPATH**/ ?>