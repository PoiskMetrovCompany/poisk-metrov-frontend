<div class="price-change row">
    <div><?php echo e($date); ?></div>
    <div class="price-change price-difference">
        <?php if(str_contains($change, '-')): ?>
            <div class="icon content-triangle green rotated d20x20"></div>
        <?php elseif(str_contains($change, '+')): ?>
            <div class="icon content-triangle red d20x20"></div>
        <?php else: ?>
            <div class="icon price-point orange d8x8"></div>
        <?php endif; ?>
        <?php echo e($change); ?>

    </div>
    <div><?php echo e($price); ?></div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chart/price-change-row.blade.php ENDPATH**/ ?>