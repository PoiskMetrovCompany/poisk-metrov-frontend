<div class="filter-bubble base-container">
    <div class="filter-bubble container last">
        Сбросить все
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/filter-bubbles.blade.php ENDPATH**/ ?>