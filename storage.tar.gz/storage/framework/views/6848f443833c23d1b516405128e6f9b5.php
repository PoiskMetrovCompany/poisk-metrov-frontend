<?php
    $spritePositionsStr = json_encode($spritePositions);
    $metroMoveIcon = $metro_type == 'transport' ? 'car' : 'people';
?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/coordinateStorage.js'); ?>
<building-card id="<?php echo e($code); ?>" city="<?php echo e($location['code']); ?>" long="<?php echo e($longitude); ?>" lat="<?php echo e($latitude); ?>"
    buildingname="<?php echo e($name); ?>" metro="<?php echo e($metro_station); ?>" metrominutes="<?php echo e($metroMinutes); ?>"
    metromoveicon="<?php echo e($metroMoveIcon); ?>">
    <div type="top-content">
        <?php echo $__env->make('custom-elements.image-gallery', [
            'spritePositionsStr' => $spritePositionsStr,
            'spriteUrl' => $spriteUrl,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div type="map"></div>
        <div type="top-buttons">
            <?php echo $__env->make('custom-elements.button.like', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="button" class="save-coordinates-btn" data-longitude="<?php echo e($longitude); ?>" data-latitude="<?php echo e($latitude); ?>" mapactive="false">
                <div class="icon map black"></div>
            </button>
            <?php echo $__env->make('custom-elements.button.share', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div type="bottom-shadow"></div>
    </div>
    <section type="description-container">
        <h6><?php echo e($name); ?></h6>
        <header>
            <div type="group"><?php echo e($builder); ?></div>
            <div type="description"><?php echo e($location['district']); ?>, <?php echo e($address); ?></div>
            <div type="description" and="one-line">
                <?php if($metro_station != null && $metroMinutes != null): ?>
                    <?php echo $__env->make('icons.icon', ['iconClass' => 'metro-red'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span> <?php echo e($metro_station); ?> </span>
                    <span class="icon <?php echo e($metroMoveIcon); ?>"></span>
                    <span> <?php echo e($metroMinutes); ?> </span>
                <?php else: ?>
                    <span style="height: 24px; display: block;">&nbsp;</span>
                <?php endif; ?>
            </div>
        </header>
        <?php echo $__env->make('common.divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <ul>
            <?php echo $__env->make('custom-elements.building-card.line', ['data' => $apartmentSpecifics, 'num' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('custom-elements.building-card.line', ['data' => $apartmentSpecifics, 'num' => 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
        <div type="more">Подробнее</div>
        <div type="additional-info">
            <ul>
                <?php echo $__env->make('custom-elements.building-card.line', ['data' => $apartmentSpecifics, 'num' => 2], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('custom-elements.building-card.line', [
                    'data' => $apartmentSpecifics,
                    'num' => 3,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
            <?php echo $__env->make('common.divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div type="subheader">
            
                <?php if($plansCount > 4): ?>
                    <?php echo e($plansCount); ?> квартир
                <?php elseif($plansCount > 1): ?>
                    <?php echo e($plansCount); ?> квартиры
                <?php elseif($plansCount == 1): ?>
                    <?php echo e($plansCount); ?> квартира
                <?php elseif(!$plansCount): ?>
                    Нет квартир
                <?php endif; ?>
            </div>
            <?php echo $__env->make('buttons.link', [
                'subclass' => 'bordered',
                'buttonText' => 'Подробнее',
                'link' => "/$code",
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
</building-card>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/building-card.blade.php ENDPATH**/ ?>