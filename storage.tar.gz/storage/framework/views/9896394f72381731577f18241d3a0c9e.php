<div class="search-bar text-search" tabindex="-1">
    <?php echo $__env->make('icons.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input placeholder="Район, метро, улица, застройщик, ЖК">
    <?php echo $__env->make('dropdown.elements.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dropdown.names.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/city-text-search.blade.php ENDPATH**/ ?>