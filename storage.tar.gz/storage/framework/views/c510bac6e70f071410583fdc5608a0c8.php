
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/mortgage.blade.php ENDPATH**/ ?>