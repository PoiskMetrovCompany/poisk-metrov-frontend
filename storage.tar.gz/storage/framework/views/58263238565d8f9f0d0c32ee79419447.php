<mobile-menu id="mobile-menu" class="mobile-menu menu-container">
    <div class="mobile-menu container">
        <div class="mobile-menu header">
            <div class="mobile-menu topbar">
                <div class="mobile-menu half">
                    <?php echo $__env->make('header.site-logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="header top-bar-half">
                    <?php echo $__env->make('header.contacts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('header.profile-buttons', [
                        'loginButtonId' => 'login-button-mobile',
                        'profileButtonId' => 'profile-button-mobile',
                        'logoutButtonId' => 'logout-button-mobile',
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="mobile-menu item">
            <div class="mobile-menu city-select">
                <div class="mobile-menu city-select item">
                    <div class="icon place orange d20x20"></div>
                    <div><?php echo e($cityName); ?></div>
                    <div class="icon arrow-tailless grey5"></div>
                </div>
                <?php $__currentLoopData = $otherCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherCity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('shared.mobile-menu.button.city', [
                        'cityCode' => $otherCity,
                        'cityName' => $cityService->cityCodes[$otherCity],
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php echo $__env->make('shared.mobile-menu.item', [
            'link' => 'sell',
            'text' => 'Продать',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.mobile-menu.item', [
            'link' => 'catalogue',
            'text' => 'Каталог недвижимости',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.mobile-menu.item', [
            'link' => 'about-us',
            'text' => 'О компании',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.mobile-menu.item', [
            'link' => 'mortgage',
            'text' => 'Ипотека',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.mobile-menu.item', [
            'link' => 'for-partners',
            'text' => 'Партнёрам',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.mobile-menu.item', [
            'link' => 'offices',
            'text' => 'Офисы',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</mobile-menu>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/shared/mobile-menu.blade.php ENDPATH**/ ?>