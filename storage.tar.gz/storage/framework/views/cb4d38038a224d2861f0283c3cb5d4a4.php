<div class="added-popup base-container">
    <div class="added-popup header">
        <div class="added-popup title">
            Добавлено в избранное
        </div>
        <div class="icon action-close"></div>
    </div>
    <div class="added-popup content">
        <div class="added-popup title">
            -
        </div>
        <div class="added-popup price">
            -
        </div>
        <div class="building-cards description one-line">
            <img src="<?php echo e(Vite::asset('resources/assets/metro/metro-red.svg')); ?>" class="icon transparent-background">
            <span> </span>
            <span class="icon d24x24 orange"></span>
            <span> </span>
        </div>
    </div>
    <a class="added-popup button" href="/favorites">Избранное</a>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/favorites/added-popup.blade.php ENDPATH**/ ?>