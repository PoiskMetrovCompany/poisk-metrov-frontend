<a href="https://t.me/poisk_metrov" target="_blank" class="footer subscribe-to-telegram container">
    <div class="footer subscribe-to-telegram telegram-button">
        <div class="icon telegram white"></div>
    </div>
    <div class="footer subscribe-to-telegram text-container">
        <div class="footer subscribe-to-telegram title">Подпишитесь на наш Telegram-канал</div>
        <div class="footer subscribe-to-telegram description">и будьте в курсе событий и полезных новостей!</div>
    </div>
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/sub-to-telegram.blade.php ENDPATH**/ ?>