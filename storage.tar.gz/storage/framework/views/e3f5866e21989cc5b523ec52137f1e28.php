<div class="footer contacts info address-media title">АДРЕС ОФИСА</div>


<a href="https://yandex.ru/maps/65/novosibirsk/house/ulitsa_dusi_kovalchuk_276k13/bEsYfwVkTkYEQFtvfXx3cHVrbA==/?ll=82.925001%2C55.062057&z=18.4"
    target="_blank" class="footer contacts info address-media description underline">
    <div>г. Новосибирск</div>
    <div>Дуси Ковальчук, 276</div>
    <div>(корпус 13)</div>
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/address.blade.php ENDPATH**/ ?>