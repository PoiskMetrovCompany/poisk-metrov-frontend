<div id="login-form-code-popup" class="auth-popup background">
    <div class="auth-popup base-container">
        <?php echo $__env->make('authorization.popup-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form autocomplete="off" id="login-form-code" class="auth-popup form" onsubmit="return false;">
            <?php echo csrf_field(); ?>
            <div class="login text-container">
                <div>
                    Вам поступит звонок на номер <br />
                    <span id="sent-number-id">-
                        <span class="login underlined" style="display: none">
                            Изменить
                        </span>
                    </span><br />
                    Отвечать необязательно.
                </div>
            </div>
            <?php echo $__env->make('inputs.code', [
                'codeInputTitle' => 'Введите последние 4 цифры номера',
                'id' => 'authorize-code',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="auth-popup code-recieve">
                <div id="send-code-again-button" class="common-button">Получить код заново</div>
                <span>Перезвонить повторно через 00:<span id="code-timer">59</span></span>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/authorization/input-code-popup.blade.php ENDPATH**/ ?>