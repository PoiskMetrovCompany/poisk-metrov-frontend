<div id="quiz" class="quiz popup">
    <div id="quiz-popup-close-tint" class="quiz tint"></div>
    <div class="quiz container">
        <iframe loading="lazy" class="quiz embed"></iframe>
        <div id="quiz-popup-close-cross" class="icon action-close white"></div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/foreign/quiz.blade.php ENDPATH**/ ?>