<?php $__env->startSection('content'); ?>
<div class="errors base-container">
    <div class="errors text-container">
        <h1><?php echo e($code); ?></h1>
        <p><?php echo e($reason); ?></p>
    </div>
    <?php echo $__env->make(
    'buttons.link',
    [
        'link' => '/',
        'buttonText' => 'Перейти на главную'
    ]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('document-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/errors/template.blade.php ENDPATH**/ ?>