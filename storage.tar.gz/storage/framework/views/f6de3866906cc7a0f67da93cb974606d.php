<!-- Yandex.Metrika counter -->

<noscript>
    <div><img src="https://mc.yandex.ru/watch/96814411" style="position:absolute; left:-9999px;" alt="" /></div>
</noscript>

<!-- /Yandex.Metrika counter -->
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/yandex-metrika.blade.php ENDPATH**/ ?>