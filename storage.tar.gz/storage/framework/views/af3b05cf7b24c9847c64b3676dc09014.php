<a href="<?php echo e($link); ?>" target="_blank">
    <?php echo $__env->make('icons.arrow-left-down', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo e($text); ?>

</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/social-media-link.blade.php ENDPATH**/ ?>