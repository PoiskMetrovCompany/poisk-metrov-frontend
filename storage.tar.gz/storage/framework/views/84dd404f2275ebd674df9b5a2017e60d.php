<a class="plan-card img-container" href="/<?php echo e($offerId); ?>">
    <img src="<?php echo e($planUrl); ?>" class="plan-card img">
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/cards/plan/image.blade.php ENDPATH**/ ?>