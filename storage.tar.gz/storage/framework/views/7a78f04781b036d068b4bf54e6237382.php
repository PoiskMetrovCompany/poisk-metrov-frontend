<div class="catalog home">
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/gallery/homePageCardsGallery.js'); ?>
    <div class="section-header">
        <div class="title first">Лучшие предложения</div>
        <?php echo $__env->make('common.arrow-buttons-container', ['id' => 'catalogue-grid-buttons'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="catalogue-grid" class="building-cards grid horizontal">
        <?php
            if (!isset($catalogueItems)) {
                $catalogueItems = $cachingService->getCards(
                    $residentialComplexRepository->getBestOffers()->pluck('code')->toArray(),
                );
            }
        ?>
        <?php $__currentLoopData = $catalogueItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestOffer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('custom-elements.building-card', $bestOffer, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo $__env->make('buttons.link', [
        'subclass' => 'centered',
        'link' => '/catalogue',
        'buttonText' => 'Перейти в каталог',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/best-offers.blade.php ENDPATH**/ ?>