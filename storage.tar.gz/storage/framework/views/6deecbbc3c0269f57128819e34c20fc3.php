<?php echo $__env->make('filters.buttons-grid', [
    'id' => 'rooms-buttons',
    'buttonsTitle' => 'Количество комнат',
    'containerClass' => 'filter-toggles buttons-container rooms',
    'elements' => $searchData->dropdownData->rooms,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/filters/buttons/rooms.blade.php ENDPATH**/ ?>