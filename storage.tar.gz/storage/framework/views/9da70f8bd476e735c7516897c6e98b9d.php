<form autocomplete="off" id="leave-contacts-form" name="leave-contacts-form" class="footer got-questions form container">
    <?php echo csrf_field(); ?>
    <div class="footer got-questions form form-container">
        <?php echo $__env->make('inputs.name', ['style' => 'footer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inputs.last-name', ['style' => 'footer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inputs.middle-name', ['style' => 'footer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inputs.phone', ['style' => 'footer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="footer got-questions form submit-button-container">
            <input type="submit" name="footer-submit-button" value=" "
                class="footer got-questions form submit-button">
            <div class="footer got-questions form submit-button-sub-container">
                <div class="footer got-questions form submit-button-text">Отправить</div>
                <img src="<?php echo e(Vite::asset('resources/assets/arrows/arrow-right-white.svg')); ?>">
            </div>
        </div>
    </div>
    <?php echo $__env->make('common.you-agree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/leave-contacts-form.blade.php ENDPATH**/ ?>