<?php if(!isset($hideCounter) || !$hideCounter): ?>
    <span class="filter counter">0</span>
<?php else: ?>
    <span class="filter counter hidden-forever">0</span>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/elements/counter.blade.php ENDPATH**/ ?>