<div class="header contacts-container">
    <a class="header phone" target="_blank" href="tel:8 (800) 444-40-45">8 (800) 444-40-45</a>
</div><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/contacts.blade.php ENDPATH**/ ?>