<?php if(isset($data[$num])): ?>
    <li>
        <div type="subheader"><?php echo e($data[$num]['name']); ?></div>
        <div>от <?php echo e($data[$num]['min-square']); ?> м²</div>
        <div>от <?php echo e($data[$num]['min-price']); ?></div>
    </li>
<?php else: ?>
    <li>
        <div type="subheader">&nbsp;</div>
        <div>&nbsp;</div>
        <div>&nbsp;</div>
    </li>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/building-card/line.blade.php ENDPATH**/ ?>