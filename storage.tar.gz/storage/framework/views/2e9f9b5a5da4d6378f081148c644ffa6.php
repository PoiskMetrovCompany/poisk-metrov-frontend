<div class="header profile-buttons">
    <a href="/favorites" class="header like-wrapper">
        <div class="header round-button">
            <?php echo $__env->make('icons.like', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php
                $favCount = $favoritesService->countFavorites();
            ?>
            <div class="header counter" <?php if($favCount == 0): ?> style="display: none" <?php endif; ?>>
                <?php echo e($favCount); ?>

            </div>
        </div>
        <div class="not-md">Избранное</div>
    </a>
    <?php echo $__env->make('favorites.added-popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(auth()->guard()->check()): ?>
        <a href="javascript:void(0)" class="header like-wrapper" id="<?php echo e($profileButtonId); ?>">
            <div class="header round-button">
                <?php echo $__env->make('icons.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div><?php echo e($user->name); ?></div>
        </a>
        <?php echo $__env->make('menus.profile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <a href="javascript:void(0)" class="header like-wrapper" id="<?php echo e($loginButtonId); ?>">
            <div class="header round-button">
                <?php echo $__env->make('icons.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="not-mobile">Войти</div>
        </a>
    <?php endif; ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/profile-buttons.blade.php ENDPATH**/ ?>