<fieldset class="input-fieldset">
    <legend class="input-legend"><?php echo e($codeInputTitle ?? 'Код из СМС'); ?></legend>
    <input class="input-text" type="number" id=<?php echo e($id ?? 'code'); ?> name="code" required>
</fieldset>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/inputs/code.blade.php ENDPATH**/ ?>