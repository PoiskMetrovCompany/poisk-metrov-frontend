<div class="custom-dropdown base-container" allowMultiple=<?php echo e($options->allowMultiple); ?>>
    <?php $__currentLoopData = $options->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="custom-dropdown text-item" <?php echo $__env->make('dropdown.copy-option-attributes', ['option' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
            <?php echo $__env->make('custom-elements.parts.checkbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <span><?php echo e($item->displayName); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/options/generic.blade.php ENDPATH**/ ?>