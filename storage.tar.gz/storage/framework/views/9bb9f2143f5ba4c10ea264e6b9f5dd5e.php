<div class="footer contacts info address-media title">СОЦИАЛЬНЫЕ СЕТИ</div>
<div class="footer contacts info address-media description">
    <?php echo $__env->make('footer.social-media-link', [
        'link' => 'https://t.me/poisk_metrov',
        'text' => 'Telegram',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('footer.social-media-link', [
        'link' => 'https://wa.me/79994484695',
        'text' => 'WhatsApp',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('footer.social-media-link', [
        'link' => 'https://instagram.com/poisk_metrov',
        'text' => 'Instagram',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/social-media.blade.php ENDPATH**/ ?>