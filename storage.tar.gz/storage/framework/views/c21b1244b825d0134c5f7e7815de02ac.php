<button id=<?php echo e($id); ?> class="chat-window category-button">
    <?php echo e($text); ?>

</button>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/button/category.blade.php ENDPATH**/ ?>