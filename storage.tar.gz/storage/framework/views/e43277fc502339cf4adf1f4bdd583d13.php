<div id="<?php echo e($id); ?>" class="custom-dropdown base-container">
    <?php echo $__env->make('search.mobile-header', [
        'headerTitle' => $context,
        'backButtonId' => "$id-back",
        'resetButtonId' => "$id-reset",
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="search-bar text-search small" tabindex="-1">
        <?php echo $__env->make('icons.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input placeholder="<?php echo e($context); ?>">
        <?php echo $__env->make('dropdown.elements.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="search-grid small-menu-list" field=<?php echo e($searchData->field); ?>>
        <?php $__currentLoopData = $searchData->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="names-dropdown item" <?php echo $__env->make('dropdown.names.copy-name-attributes', [
                'item' => $item,
                'field' => $searchData->field,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
                <div>
                    <?php echo $__env->make('custom-elements.parts.checkbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span><?php echo e($item->name); ?></span>
                    <span><?php echo e($context); ?></span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/options/with-checkbox.blade.php ENDPATH**/ ?>