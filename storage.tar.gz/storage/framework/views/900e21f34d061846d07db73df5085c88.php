<div id="current-city-mobile-button" class="header city-flex selected current">
    <?php echo $__env->make('icons.place', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo e($cityName); ?>

</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/current-city.blade.php ENDPATH**/ ?>