<div class="learn-sale-card">
    <div class="learn-sale-card text">Узнать о старте продаж первым</div>
    <img src="<?php echo e(Vite::asset('resources/assets/space.svg')); ?>" class="space">
    <?php echo $__env->make('buttons.common', [
        'buttonId' => 'learn-about-first-sale-menu-button',
        'buttonText' => 'Подробнее',
        'subclass' => 'white',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/cards/learn-about-first-sale.blade.php ENDPATH**/ ?>