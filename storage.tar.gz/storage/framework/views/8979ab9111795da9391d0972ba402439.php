<?php
    $queryString = Request::getQueryString();

    if ($queryString != '') {
        $queryString = "?$queryString";
    }
?>

<image-gallery spritepositions="<?php echo e($spritePositionsStr); ?>" style="background-image: url(<?php echo e("/storage/$spriteUrl"); ?>)">
    
    <a type="card-area" href="/<?php echo e($code); ?><?php echo e($queryString); ?>">
        <?php for($i = 0; $i < 5 && $i < count($spritePositions); $i++): ?>
            <div></div>
        <?php endfor; ?>
    </a>
    <div type="slider-indicators">
        <?php for($i = 0; $i < 5 && $i < count($spritePositions); $i++): ?>
            <div></div>
        <?php endfor; ?>
    </div>
</image-gallery>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/image-gallery.blade.php ENDPATH**/ ?>