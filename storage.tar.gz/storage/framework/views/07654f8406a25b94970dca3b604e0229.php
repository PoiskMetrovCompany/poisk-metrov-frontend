<?php if(count($recommendations)): ?>
    <div class="base-container">
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/homePage/apartmentSuggestions.js'); ?>
        <div class="title-flex">
            <div class="title">
                Подборки квартир
            </div>
            <?php echo $__env->make('common.arrow-buttons-container', ['id' => 'apartment-suggestions-buttons'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div id="apartment-suggestions-cards" class="apartment-suggestions base-container">
            <?php
                $cardAdded = false;
                $i = 0;
            ?>
            <?php for($i = 0; $i < count($recommendations); $i++): ?>
                <?php if($i == 2 && !$cardAdded): ?>
                    <?php echo $__env->make('home-page.category-suggestion-card', [
                        'text' => 'Квартиры</br>и апартаменты бизнес-класса',
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php
                        $i--;
                        $cardAdded = true;
                    ?>
                <?php else: ?>
                    <?php echo $__env->make('cards.plan.card', [
                        'name' => '',
                        'offerId' => $recommendations[$i]['offer_id'],
                        'planUrl' => $recommendations[$i]['plan_URL'],
                        'formattedPrice' => $recommendations[$i]['displayPrice'],
                        'type' => $recommendations[$i]['apartment_type'],
                        'area' => $recommendations[$i]['area'],
                        'floor' => $recommendations[$i]['floor'],
                        'maxFloor' => $recommendations[$i]['floors_total'],
                        'quarter' => $recommendations[$i]['ready_quarter'],
                        'builtYear' => $recommendations[$i]['built_year'],
                        'material' => $recommendations[$i]['building_materials'],
                        'finishing' => $recommendations[$i]['renovation'],
                        'isFavoriteApartment' => $recommendations[$i]['isFavoriteApartment'],
                        'priceDifference' => $recommendations[$i]['priceDifference'],
                        'hidePriceChangeButtonText' => true,
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('chart.price-chart', [
                        'historicApartmentPrice' => $recommendations[$i]['displayPrice'],
                        'code' => $recommendations[$i]['offer_id'],
                        'apartment_type' => $recommendations[$i]['apartment_type'],
                        'area' => $recommendations[$i]['area'],
                        'history' => $recommendations[$i]['history'],
                        'firstDate' => $recommendations[$i]['firstDate'],
                        'lastDate' => $recommendations[$i]['lastDate'],
                        'lastChanges' => $recommendations[$i]['lastChanges'],
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/apartment-suggestions.blade.php ENDPATH**/ ?>