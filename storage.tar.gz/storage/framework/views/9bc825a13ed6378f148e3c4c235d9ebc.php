<?php echo $__env->make('buttons.common', [
    'buttonId' => $buttonId,
    'buttonText' => $buttonText,
    'buttonIcon' => $buttonIcon,
    'subclass' => 'bordered',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/buttons/bordered.blade.php ENDPATH**/ ?>