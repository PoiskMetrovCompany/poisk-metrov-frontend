<div id="personal-info" class="auth-popup background">
    <div class="auth-popup base-container">
        <?php echo $__env->make('authorization.popup-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form autocomplete="off" id="personal-info-form" class="auth-popup form" onsubmit="return false;">
            <?php echo csrf_field(); ?>
            <div class="login text-container">
                Заполните короткую анкету ниже - она необходима для корректной работы личного кабинета.
            </div>
            <?php echo $__env->make('inputs.name', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('inputs.surname', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <input type="submit" class="peinag button active" value="Сохранить">
        </form>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/authorization/personal-info.blade.php ENDPATH**/ ?>