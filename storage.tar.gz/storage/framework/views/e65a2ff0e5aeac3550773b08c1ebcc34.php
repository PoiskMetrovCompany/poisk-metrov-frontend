<div class="search-grid container-mobile-small">
    <?php echo $__env->make('buttons.bordered', [
        'buttonId' => 'show-filters-menu-mobile',
        'buttonIcon' => 'filters-button',
        'buttonText' => 'Фильтры',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('buttons.bordered', [
        'buttonId' => 'show-best-offers-on-map-mobile',
        'buttonIcon' => 'paper-map',
        'buttonText' => 'На карте',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/primary-buttons-mobile.blade.php ENDPATH**/ ?>