<footer id="have-questions" class="footer base-container common-padding">
    <div class="footer got-questions container">
        <?php echo $__env->make('footer.got-questions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('footer.leave-contacts-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="footer divider"> </div>
    <?php echo $__env->make('footer.sub-to-telegram', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('footer.sub-to-telegram-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="footer divider"> </div>
    <div class="footer contacts container">
        <div class="footer contacts info container">
            <?php echo $__env->make('footer.our-contacts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="footer contacts info address-media grid">
                <div class="footer contacts info address-media column">
                    <?php echo $__env->make('footer.address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="footer contacts info address-media column">
                    <?php echo $__env->make('footer.social-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('footer.copyright', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</footer>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/footer.blade.php ENDPATH**/ ?>