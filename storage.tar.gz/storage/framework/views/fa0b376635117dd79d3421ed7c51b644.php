<div id="<?php echo e($id); ?>" class="filter-toggles container" allowMultiple=<?php echo e($elements->allowMultiple); ?>>
    <span><?php echo e($buttonsTitle); ?></span>
    <div
        <?php if(isset($containerClass)): ?>
            class="<?php echo e($containerClass); ?>"
        <?php else: ?>
            class="filter-toggles buttons-container fit-any"
        <?php endif; ?>>
        <?php $__currentLoopData = $elements->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" class="filter-toggles button room" <?php echo $__env->make('dropdown.copy-option-attributes', ['option' => $option], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
                <?php if(isset($option->shortName)): ?>
                    <?php echo e($option->shortName); ?>

                <?php else: ?>
                    <?php echo e($option->displayName); ?>

                <?php endif; ?>
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/filters/buttons-grid.blade.php ENDPATH**/ ?>