<div class="reciever message base-container">
    <div class="message site-logo-as-icon">
        <img src="<?php echo e(Vite::asset('resources/assets/site-logo.svg')); ?>" />
    </div>
    <div class="reciever message text-container">
        <div class="message reciever name-and-text">
            <h6>Ассистент поддержки</h6>
            <div><?php echo e($messageText); ?></div>
        </div>
        <div class="message time"><?php echo e($time); ?></div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/messages/agent.blade.php ENDPATH**/ ?>