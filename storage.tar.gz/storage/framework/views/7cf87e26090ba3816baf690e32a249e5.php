<?php
    $historyLength = count($history);
    $historyString = json_encode($history);
?>

<div class="sub-menus background" id="price-chart-modal-<?php echo e($code); ?>">
    <input type="hidden" value="<?php echo e($historyString); ?>" id="history-data-<?php echo e($code); ?>">
    <div class="sub-menus card fit-content" id="price-chart-card">
        <div class="sub-menus chart-card">
            <div class="sub-menus top">
                <div class="sub-menus header">
                    <div class="sub-menus title">
                        <?php if(isset($apartment_type)): ?>
                            <?php echo e($apartment_type); ?>,
                        <?php endif; ?>
                        <?php echo e($area); ?> м² - <?php echo e($historicApartmentPrice); ?>

                    </div>
                </div>
                <div class="sub-menus close">
                    <div class="icon action-close d16x16 orange"></div>
                </div>
            </div>
            <div>
                <?php if(count($history) > 0): ?>
                    <?php echo $__env->make('chart.price-change-row', [
                        'date' => $history[0]['date'],
                        'change' => 'Начальная цена',
                        'price' => $priceFormattingService->fullPrice($history[0]['price']),
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(count($lastChanges) > 2): ?>
                    <?php for($i = 0; $i < 3; $i++): ?>
                        <?php echo $__env->make('chart.price-change-row', [
                            'date' => $history[$historyLength - 3 + $i]['date'],
                            'change' => $lastChanges[$i]['change'],
                            'price' => $lastChanges[$i]['price'],
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="price-change divider"></div>
                    <?php endfor; ?>
                <?php elseif(count($lastChanges) == 2): ?>
                    <?php for($i = 0; $i < count($lastChanges); $i++): ?>
                        <?php echo $__env->make('chart.price-change-row', [
                            'date' => $history[$historyLength - 2 + $i]['date'],
                            'change' => $lastChanges[$i]['change'],
                            'price' => $lastChanges[$i]['price'],
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="price-change divider"></div>
                    <?php endfor; ?>
                <?php elseif(count($lastChanges) > 0): ?>
                    <?php echo $__env->make('chart.price-change-row', [
                        'date' => $history[$historyLength - 1]['date'],
                        'change' => $lastChanges[0]['change'],
                        'price' => $lastChanges[0]['price'],
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="price-change divider"></div>
                <?php endif; ?>
            </div>
            <div class="price-change chart">
                <canvas id="price-chart-<?php echo e($code); ?>"></canvas>
            </div>
            <div class="price-change date-marks">
                <div class="price-change date-mark">
                    <?php echo e($firstDate); ?>

                </div>
                <div class="price-change date-mark">
                    <?php echo e($lastDate); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chart/price-chart.blade.php ENDPATH**/ ?>