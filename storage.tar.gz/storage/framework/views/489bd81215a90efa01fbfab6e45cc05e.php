<div <?php if(isset($isVisible) && $isVisible == true): ?> class="quiz step visible" <?php else: ?> class="quiz step" <?php endif; ?>>
    <?php echo $__env->make('quiz.title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(isset($buttonTexts)): ?>
        <div class="quiz buttons">
            <?php $__currentLoopData = $buttonTexts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buttonText): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('buttons.common', ['subclass' => 'white'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <form id="quiz-form" autocomplete="off">
            <?php echo $__env->make('inputs.phone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <input type="submit" class="peinag button" value="Отправить заявку">
            <?php echo $__env->make('common.you-agree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    <?php endif; ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/quiz/step.blade.php ENDPATH**/ ?>