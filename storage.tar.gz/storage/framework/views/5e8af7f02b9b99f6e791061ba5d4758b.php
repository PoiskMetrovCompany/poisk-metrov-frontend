<div class="footer got-questions info container">
    <div class="footer got-questions info title">
        Остались вопросы?
    </div>
    <div class="footer got-questions info description">
        Оставьте свои контакты, и мы свяжемся с вами в ближайшее время, чтобы ответить на них!
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/footer/got-questions.blade.php ENDPATH**/ ?>