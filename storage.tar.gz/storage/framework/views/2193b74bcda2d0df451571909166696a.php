<div id="<?php echo e($id); ?>" class="filter base-container type-specific">
    <div class="text-with-icon">
        <div class="icon <?php echo e($icon); ?> d20x20 orange"> </div>
        <span><?php echo e($previewName); ?></span>
        <?php echo $__env->make('dropdown.elements.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('icons.filter-arrow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('dropdown.options.with-checkbox', [
        'searchData' => $searchDataPart,
        'id' => $dropdownId,
        'context' => $dropdownContext,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="filter apply">
        <?php echo $__env->make('buttons.common', ['buttonText' => 'Применить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/type-specific-filter.blade.php ENDPATH**/ ?>