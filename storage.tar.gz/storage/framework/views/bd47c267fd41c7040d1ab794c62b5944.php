<?php
    $data = json_decode(json_encode($options->data), true);
    $startOptions = array_slice($data, 0, count($data));
    array_pop($startOptions);
    $endOptions = array_slice($data, 1, count($data));

    foreach ($startOptions as &$startOptionInLoop) {
        $startOptionInLoop['searchid'] = $options->searchidFrom;
        $startOptionInLoop['condition'] = '>=';
    }

    //https://www.php.net/manual/en/control-structures.foreach.php
    //Обязательно ансетим переменную чтобы не переписался последний элемент массива на предыдущий ему
    //Языку подчищать за собой - это не по царски
    unset($startOptionInLoop);

    foreach ($endOptions as &$endOptionInLoop) {
        $endOptionInLoop['searchid'] = $options->searchidTo;
        $endOptionInLoop['condition'] = '<=';
    }

    unset($endOptionInLoop);
?>

<div class="custom-dropdown base-container" allowMultiple=<?php echo e($options->allowMultiple); ?>>
    <div class="price-dropdown base-container">
        <input class="price-dropdown title" placeholder="<?php echo e($options->inputPlaceholderFrom); ?>">
        <input class="price-dropdown title" placeholder="<?php echo e($options->inputPlaceholderTo); ?>">
        <div class="price-dropdown container">
            <?php $__currentLoopData = $startOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $startOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('dropdown.elements.text-item', ['option' => $startOption], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="price-dropdown container">
            <?php $__currentLoopData = $endOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('dropdown.elements.text-item', ['option' => $endOption], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/options/compare.blade.php ENDPATH**/ ?>