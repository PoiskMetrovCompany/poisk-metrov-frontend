<?php
    $city = $cityService->where[$cityService->getUserCity()];

    if (!isset($searchData)) {
        $searchData = $searchService->getSearchData();
    }

    if (!isset($searchSubclass)) {
        $searchSubclass = '';
    }
?>

<div class="search-section base-container<?php echo e($searchSubclass); ?>">
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/homePage/homePageFilters.js'); ?>
    <div class="search-section header">
        <h2 class="title">
            <?php if($selectedCity != 'far-east'): ?>
                Недвижимость в <?php echo e($city); ?>

            <?php else: ?>
                Недвижимость на Дальнем Востоке
            <?php endif; ?>
        </h2>
        <?php echo $__env->make('buttons.bordered', [
            'buttonId' => 'show-best-offers-on-map',
            'buttonIcon' => 'paper-map',
            'buttonText' => 'На карте',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="search-section searchbar-with-button">
        <?php echo $__env->make('home-page.search-filter-menu', ['searchData' => json_decode($searchData)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('home-page.primary-buttons-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/search.blade.php ENDPATH**/ ?>