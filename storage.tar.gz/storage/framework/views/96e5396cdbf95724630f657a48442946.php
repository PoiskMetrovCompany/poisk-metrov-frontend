<?php
    $category =  $realEstateService->getRecommendedCategory();
    if (!empty($category)) {
        $categoryName = $category->category_name;
        $link = $realEstateService->getCatalogueLinkForCategory($category);

        $backgroundsForCategories = [
            'Элитные' => 1,
            'Новостройки у воды' => 2,
            'Хорошо под сдачу' => 3,
            'Быстрое заселение' => 4,
            'Рядом с метро' => 5,
            'Рядом парк и лес' => 6,
        ];
    }
?>

<?php if(!empty($category)): ?>
    <div class="apartment-suggestions category-suggestion-card"
        style="background-image: url('suggestions/<?php echo e($backgroundsForCategories[$categoryName]); ?>.jpg')">
        <h6>
            <?php if($categoryName == 'Элитные'): ?>
                Квартиры и апартаменты бизнес-класса
            <?php else: ?>
                <?php echo $categoryName; ?>

            <?php endif; ?>
        </h6>
        <?php echo $__env->make('buttons.link', [
            'link' => $link,
            'subclass' => 'white',
            'buttonText' => 'Посмотреть варианты',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/category-suggestion-card.blade.php ENDPATH**/ ?>