<form class="chat-window form invalid">
    <div>
        <button type="button">
            <?php echo $__env->make('icons.chat.attachment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
        <button type="button">
            <?php echo $__env->make('icons.chat.more', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </button>
    </div>
    <textarea type="text" rows="1" name="message" required placeholder="Сообщение"></textarea>
    <button type="submit" class="common-button">
        <?php echo $__env->make('icons.arrow-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </button>
</form>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/input.blade.php ENDPATH**/ ?>