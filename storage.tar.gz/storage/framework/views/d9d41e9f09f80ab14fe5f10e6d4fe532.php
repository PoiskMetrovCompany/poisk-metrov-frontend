<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <?php echo $__env->yieldContent('additional-meta'); ?>
    <?php if(!isset($excludeNoIndexing) || !$excludeNoIndexing): ?>
        <?php echo $__env->make('technical.no-indexing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <title><?php echo $title ?? 'Поиск метров'; ?></title>
    <link rel="icon" type="image/x-icon" href="/icon/16.ico">
    <link rel="preconnect"
        href="https://yastatic.net/s3/front-maps-static/maps-front-jsapi-3/3.0.13965858/build/static/bundles/main.js" />
    <link rel="preconnect"
        href="https://yastatic.net/s3/front-maps-static/maps-front-jsapi-3/3.0.13965858/build/static/bundles/vector.js" />
    <link rel="preconnect" href="https://mc.yandex.ru/metrika/tag.js" />
    <meta name="yandex-verification" content="e02510a91b55c5d2" />

    <?php echo $__env->yieldContent('preload-images'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/scss/styles.scss',
        'resources/css/app.css',
        'resources/js/app.js'
    ]); ?>

    <?php echo $__env->yieldContent('head'); ?>

    <?php if(App::isProduction()): ?>
        <?php echo $__env->make('scripts.clarity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->make('scripts.crm-chat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.yandex-maps-api', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.user-auth-js-variable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.current-city', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.pusher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('pagescript'); ?>
</head>

<body>
    <?php echo $__env->make('common.yandex-metrika', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="header-ancor" id="page-top"></div>
    <?php echo $__env->make('header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="temp-map-container" class="building-cards temp-map-container"></div>
    <div id="new-temp-map-container" class="building-cards temp-map-container"></div>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('menus.forms.consult-request', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>
    <?php echo $__env->make('common.bottom-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('chat.window', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('authorization.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('popups.thanks-for-contacts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('common.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('shared.toolbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('shared.mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('menus.forms.revert-ads-agreement', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('popups.ads-agreement-reverted', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('custom-elements.user-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('menus.city-selection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/document-layout.blade.php ENDPATH**/ ?>