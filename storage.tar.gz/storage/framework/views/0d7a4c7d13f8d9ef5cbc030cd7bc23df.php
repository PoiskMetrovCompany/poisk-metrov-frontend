<div class="title-card base-container">
    <?php echo $__env->make('home-page.title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a class="title-card arrow-button" href="/catalogue">
        <?php echo $__env->make('icons.arrow-left-up', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </a>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/cards/title.blade.php ENDPATH**/ ?>