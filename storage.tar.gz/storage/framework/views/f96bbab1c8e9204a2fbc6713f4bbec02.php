<div class="custom-dropdown text-item" <?php echo $__env->make('dropdown.copy-option-attributes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
    <span><?php echo e($option['displayName']); ?></span>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/elements/text-item.blade.php ENDPATH**/ ?>