<a href="/<?php echo e($link); ?>"
    <?php if(Request::is($link) || Request::is("*/$link")): ?> class="mobile-menu item  current"
    <?php else: ?> class="mobile-menu item" <?php endif; ?>>
    <div class="mobile-menu title">
        <?php echo e($text); ?>

    </div>
    <?php echo $__env->make('common.divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/shared/mobile-menu/item.blade.php ENDPATH**/ ?>