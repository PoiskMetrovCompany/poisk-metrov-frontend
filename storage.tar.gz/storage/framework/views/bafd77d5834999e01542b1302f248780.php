<form id="call-from-chat" class="chat-call base-container" autocomplete="off">
    <?php echo $__env->make('inputs.name', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inputs.phone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('common.personal-info-agreement', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('chat.button.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php echo $__env->make('buttons.common', [
    'buttonText' => 'Перезвоните мне',
    'buttonId' => 'chat-quick-call-button',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/call-me-back.blade.php ENDPATH**/ ?>