<div class="quiz title">
    <?php echo $quizTitleHtml; ?>

</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/quiz/title.blade.php ENDPATH**/ ?>