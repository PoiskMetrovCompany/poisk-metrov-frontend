<a <?php if(isset($buttonId)): ?> id="<?php echo e($buttonId); ?>" <?php endif; ?> <?php if(isset($subclass)): ?> class="common-button <?php echo e($subclass); ?>" <?php else: ?>
    class="common-button" <?php endif; ?> href="<?php echo e($link); ?>">
    <?php echo e($buttonText); ?>

</a><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/buttons/link.blade.php ENDPATH**/ ?>