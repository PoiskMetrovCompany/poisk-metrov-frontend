<?php
    if (!isset($news)) {
        $news = $newsService->getNewsForSite();
    }
?>

<?php if(count($news) > 0): ?>
    <div class="news base-container">
        <div class="title-flex">
            <div class="title">Новости</div>
        </div>
        <div class="news container">
            <?php echo $__env->make('home-page.news.card.primary', $news[0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(count($news) > 1): ?>
                <?php echo $__env->make('home-page.news.card.secondary', $news[1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(count($news) > 2): ?>
                <?php echo $__env->make('home-page.news.card.secondary', $news[2], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('buttons.link', [
            'subclass' => 'centered',
            'link' => '/news-page',
            'buttonText' => 'Читать все',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/news.blade.php ENDPATH**/ ?>