<div class="chat-window category-list">
    <?php echo $__env->make('chat.button.category', ['id' => 'dummy', 'text' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/messages/categories.blade.php ENDPATH**/ ?>