<?php
    $quizDisabled = boolval(config('app.quiz_disabled'));
?>

<?php if(!$quizDisabled): ?>
    <div id="we-choose-apartment" class="we-choose base-container">
        <div class="we-choose text-container">
            <div class="title">
                Подберём квартиру по вашим критериям!
            </div>
            <div class="we-choose description">
                Заполните анкету с параметрами недвижимости и получите индивидуальную подборку актуальных предложений
            </div>
        </div>
        <div id="quiz-popup-open" class="common-button">Начать</div>
    </div>
    <?php echo $__env->make('foreign.quiz', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/we-choose.blade.php ENDPATH**/ ?>