<?php if(!App::isProduction()): ?>
    <meta name="robots" content="noindex">
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/technical/no-indexing.blade.php ENDPATH**/ ?>