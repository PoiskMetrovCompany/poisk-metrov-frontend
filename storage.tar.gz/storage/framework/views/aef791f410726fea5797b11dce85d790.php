<?php $__currentLoopData = $option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($key); ?>="<?php echo e($value); ?>"
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/copy-option-attributes.blade.php ENDPATH**/ ?>