<div class="message base-container">
    <img src="" style="opacity: 0" />
    <div class="message text-container">
        <div><?php echo e($messageText); ?></div>
        <div class="message time"><?php echo e($time); ?></div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/messages/sender.blade.php ENDPATH**/ ?>