<div id="names-filter-dropdown" class="custom-dropdown base-container names">
    <div class="names-dropdown buttons-container">
        <?php echo $__env->make('dropdown.names.category-button', ['buttonText' => 'Все'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dropdown.names.category-button', ['buttonText' => 'Район'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dropdown.names.category-button', ['buttonText' => 'Улица'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(count($searchData->stations->values)): ?>
            <?php echo $__env->make('dropdown.names.category-button', ['buttonText' => 'Метро'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php echo $__env->make('dropdown.names.category-button', ['buttonText' => 'ЖК'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dropdown.names.category-button', ['buttonText' => 'Застройщик'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dropdown.names.close-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php if(isset($searchData)): ?>
        <div class="names-dropdown container" context="Все">
            <?php echo $__env->make('dropdown.names.list.district', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('dropdown.names.list.street', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('dropdown.names.list.metro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('dropdown.names.list.building', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('dropdown.names.list.builder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="names-dropdown container" context="Район">
            <?php echo $__env->make('dropdown.names.list.district', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="names-dropdown container" context="Улица">
            <?php echo $__env->make('dropdown.names.list.street', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="names-dropdown container" context="Метро">
            <?php echo $__env->make('dropdown.names.list.metro', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="names-dropdown container" context="ЖК">
            <?php echo $__env->make('dropdown.names.list.building', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="names-dropdown container" context="Застройщик">
            <?php echo $__env->make('dropdown.names.list.builder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php else: ?>
        <?php echo $__env->make('dropdown.names.nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/filter.blade.php ENDPATH**/ ?>