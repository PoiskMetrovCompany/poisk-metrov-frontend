<div class="reciever message base-container">
    <img src="<?php echo e($profilePicUrl); ?>" />
    <div class="message site-logo-as-icon" style="display: none">
        <img src="<?php echo e(Vite::asset('resources/assets/site-logo.svg')); ?>" />
    </div>
    <div class="reciever message text-container">
        <div class="message reciever name-and-text">
            <h6><?php echo e($recieverName); ?></h6>
            <div><?php echo e($messageText); ?></div>
        </div>
        <div class="message time"><?php echo e($time); ?></div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/messages/reciever.blade.php ENDPATH**/ ?>