<h1>
    <span class="link-highlight">Поиск Метров</span> — бесплатный сервис бронирования новостроек
</h1><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/title.blade.php ENDPATH**/ ?>