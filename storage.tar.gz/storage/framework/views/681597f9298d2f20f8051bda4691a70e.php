<div class="peinag container">
    <div class="peinag checkbox-borders">
        <input id="conscent-checkbox" name="consent-checkbox" type="checkbox" class="peinag checkbox" required>
    </div>
    <div class="peinag description">
        Нажимая на кнопку, вы даете согласие на обработку<a href="/policy">своих персональных данных</a>
        и согласие на получение<a href="/ads-agreement">рекламных рассылок</a>.
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/you-agree.blade.php ENDPATH**/ ?>