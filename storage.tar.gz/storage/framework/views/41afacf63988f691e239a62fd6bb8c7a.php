<a class="mobile-menu city-select item unselected" href="/switch-city?new_city=<?php echo e($cityCode); ?>">
    <div class="icon place orange d20x20"></div>
    <div><?php echo e($cityName); ?></div>
</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/shared/mobile-menu/button/city.blade.php ENDPATH**/ ?>