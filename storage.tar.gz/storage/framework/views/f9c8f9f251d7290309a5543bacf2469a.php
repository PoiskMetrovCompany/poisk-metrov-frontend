<?php if(isset($coordinates)): ?>
    <div class="hint base-container">
        <div class="hint container"><?php echo e($text); ?></div>
    </div>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/hint.blade.php ENDPATH**/ ?>