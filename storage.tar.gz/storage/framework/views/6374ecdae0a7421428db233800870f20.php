<?php
    $chatEnabled = boolval(config('app.chat_enabled'));
?>

<?php if($chatEnabled): ?>
    <div class="chat-window base-container">
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/chat/chatLoader.js'); ?>
        <?php echo $__env->make('chat.button.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('chat.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="chat-window message-container">
            <?php echo $__env->make('chat.call-me-back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('chat.call-for-apartment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('chat.message-templates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('chat.funnel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('chat.input', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php endif; ?><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/window.blade.php ENDPATH**/ ?>