<a href="/<?php echo e($link); ?>" current="<?php echo e(Request::is($link) || Request::is("*/$link")); ?>">
    <?php echo e($text); ?>

</a>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/big-link.blade.php ENDPATH**/ ?>