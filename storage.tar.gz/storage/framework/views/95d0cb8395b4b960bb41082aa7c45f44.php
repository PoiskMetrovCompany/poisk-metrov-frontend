<div class="search-grid menu-header">
    <button type="button" <?php if(isset($backButtonId)): ?>
    id="<?php echo e($backButtonId); ?>"        
    <?php endif; ?>>
        <div class="icon arrow-tailless"></div>
        <span>Назад</span>
    </button>
    <div><?php echo e($headerTitle ?? 'Фильтр'); ?></div>
    <button type="button" <?php if(isset($resetButtonId)): ?>
    id="<?php echo e($resetButtonId); ?>" 
    <?php endif; ?>>
        Сбросить</button>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/search/mobile-header.blade.php ENDPATH**/ ?>