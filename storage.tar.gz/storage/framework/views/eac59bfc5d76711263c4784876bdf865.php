<?php $__currentLoopData = $searchData->districts->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('dropdown.names.search-item', [
        'item' => $item,
        'context' => 'Район',
        'icon' => 'search-location',
        'field' => $searchData->districts->field,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/list/district.blade.php ENDPATH**/ ?>