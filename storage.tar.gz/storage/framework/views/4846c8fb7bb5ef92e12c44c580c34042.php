<link rel="preload" as="image" href=<?php echo e(Vite::asset('resources/assets/site-logo.svg')); ?>>
<a href="/" class="header site-logo">
    <img src="<?php echo e(Vite::asset('resources/assets/site-logo.svg')); ?>" />
</a><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/site-logo.blade.php ENDPATH**/ ?>