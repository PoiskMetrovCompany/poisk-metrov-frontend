<header id="top-bar" class="header top-bar common-padding">
    <div class="header top-bar main">
        <div class="header vertical-content">
            <?php echo $__env->make('header.city-selection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('header.small-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="header vertical-content">
            <div class="header top-bar-half">
                <?php echo $__env->make('header.site-logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('header.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="header top-bar-half">
                <?php echo $__env->make('header.contacts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('header.current-city', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('header.profile-buttons', [
                    'loginButtonId' => 'login-button',
                    'profileButtonId' => 'profile-button',
                    'logoutButtonId' => 'logout-button',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/header/header.blade.php ENDPATH**/ ?>