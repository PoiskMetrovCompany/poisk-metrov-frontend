<div class="sub-menus background" id="ads-agreement-reverted">
    <div class="sub-menus card" id="ads-reverted-popup">
        <div class="sub-menus container">
            <div class="sub-menus top">
                <div class="sub-menus header">
                    <div class="sub-menus title"></div>
                </div>
                <div class="sub-menus close">
                    <div class="icon action-close d16x16 orange"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/popups/ads-agreement-reverted.blade.php ENDPATH**/ ?>