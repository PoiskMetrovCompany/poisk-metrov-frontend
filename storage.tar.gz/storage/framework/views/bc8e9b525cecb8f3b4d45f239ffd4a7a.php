<city-selection open="0">
    <dialog>
        <header>
            <div>
                Выберите город
            </div>
            <button>
                <?php echo $__env->make('icons.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </button>
        </header>
        <section>
            <div type="hint">
                Текущий город
            </div>
            <div type="current">
                <?php echo $__env->make('icons.check', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <span><?php echo e($cityName); ?></span>
            </div>
        </section>
        <nav>
            <ul>
                <?php $__currentLoopData = $cityService->getSortedCityNamesAndCodes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cityNameSorted => $cityCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="/switch-city?new_city=<?php echo e($cityCode); ?>" current="<?php echo e($selectedCity == $cityCode); ?>">
                            <?php echo e($cityNameSorted); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
    </dialog>
</city-selection>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/menus/city-selection.blade.php ENDPATH**/ ?>