<div id="<?php echo e($id); ?>" tabindex="-1" class="plan-card card-button <?php echo e($subclass ?? ''); ?>">
    <div class="icon action-share-grey d24x24 black"></div>
    <?php echo $__env->make('common.hint', ['text' => 'Поделиться'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="building-cards social-media menu with-border">
        <div class="building-cards social-media text-with-icon">
            <div class="icon link-transparent orange"></div>
            <div>Скопировать ссылку</div>
        </div>
        <div class="building-cards social-media text-with-icon" id="<?php echo e($id); ?>-share-telegram">
            <div class="icon telegram-transparent orange d24x24"></div>
            <div>Telegram</div>
        </div>
        <div class="building-cards social-media text-with-icon" id="<?php echo e($id); ?>-share-watsapp">
            <div class="icon whatsapp-transparent orange d24x24"></div>
            <div>WhatsApp</div>
        </div>
        <div class="building-cards social-media text-with-icon">
            <div>Закрыть</div>
        </div>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/share-page-button.blade.php ENDPATH**/ ?>