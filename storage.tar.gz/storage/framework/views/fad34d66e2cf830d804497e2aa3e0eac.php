<?php
    $checkedClass = '';

    if (!isset($subclass)) {
        $subclass = '';
    }

    if (isset($checked) && $checked == true) {
        $checked = true;
        $checkedClass = 'checked';
    } else {
        $checked = false;
    }

    $reallyAllowMultiple =
        !isset($options) ||
        (isset($options->allowMultiple) && $options->allowMultiple == true) ||
        (isset($allowMultiple) && $allowMultiple == true);

    if (!$reallyAllowMultiple && $subclass == '') {
        $subclass = 'radio-button';
    }
?>

<div class="pseudo-checkbox <?php echo e($subclass); ?> <?php echo e($checkedClass); ?>">
    <div class="icon checkbox-check"></div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/parts/checkbox.blade.php ENDPATH**/ ?>