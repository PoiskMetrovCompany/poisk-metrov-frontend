<a class="up-button" href="#page-top">
    <div class="icon arrow-up d40x40"></div>
</a><?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/up-button.blade.php ENDPATH**/ ?>