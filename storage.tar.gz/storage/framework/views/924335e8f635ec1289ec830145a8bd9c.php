<?php echo $__env->make('filters.range', [
    'min' => $searchData->cheapest,
    'max' => $searchData->most_expensive,
    'id' => 'price-min-max-range',
    'legend' => 'Стоимость, млн ₽',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/filters/range/price.blade.php ENDPATH**/ ?>