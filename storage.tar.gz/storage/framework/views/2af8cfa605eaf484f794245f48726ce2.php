<div class="names-dropdown item" <?php echo $__env->make('dropdown.names.copy-name-attributes', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>>
    <div>
        <div class="icon <?php echo e($icon); ?>"> </div>
        <span><?php echo e($item->name); ?></span>
        <span><?php echo e($context); ?></span>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/dropdown/names/search-item.blade.php ENDPATH**/ ?>