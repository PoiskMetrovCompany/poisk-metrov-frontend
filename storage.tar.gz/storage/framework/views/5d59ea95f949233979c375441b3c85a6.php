<form class="search-grid base-container">
    <?php echo $__env->make('search.mobile-header', [
        'backButtonId' => 'close-filter-menu-button',
        'resetButtonId' => 'reset-filters-button',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('search.filter-bubbles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('search.search-bar', ['searchData' => $searchData], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('buttons.submit', [
        'buttonText' => "Показать {$searchData->apartment_count} квартир",
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/home-page/search-filter-menu.blade.php ENDPATH**/ ?>