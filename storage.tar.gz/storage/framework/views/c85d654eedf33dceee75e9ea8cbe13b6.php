<contained-checkbox id=<?php echo e($id); ?>>
    <?php echo $__env->make('custom-elements.parts.checkbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('custom-elements.parts.placeholder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</contained-checkbox>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/contained-checkbox.blade.php ENDPATH**/ ?>