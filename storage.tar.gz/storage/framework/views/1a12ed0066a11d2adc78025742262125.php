
<div class="plan-card container" offerId="<?php echo e($offerId); ?>" apartment_type="<?php echo e($type); ?>"
    area="<?php echo e($area); ?> м²" price="<?php echo e($formattedPrice); ?>">
    <div class="plan-card small-card">
        <div class="plan-card header">
            <a target="_self" href="/<?php echo e($offerId); ?>">
                <?php echo e($name); ?>

            </a>
            <div class="plan-card icons">
                <div tabindex="-1" class="plan-card card-button <?php echo $isFavoriteApartment ? 'orange' : ''; ?>">
                    <div class="icon action-like d24x24 black"></div>
                    <?php echo $__env->make('common.hint', ['text' => 'Добавить в избранное'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php echo $__env->make('common.share-page-button', [
                    'id' => "share-apartment-button-$offerId",
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make('cards.plan.image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="plan-card short-description">
            <div class="plan-card title"><?php echo e($formattedPrice); ?></div>
            <div class="plan-card line-desc">
                <?php echo $__env->make('cards.plan.description-line', [
                    'text' => "$type",
                    'valueToCheck' => $type,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('cards.plan.dot-divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('cards.plan.description-line', [
                    'text' => "$area м²",
                    'valueToCheck' => $area,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('cards.plan.dot-divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('cards.plan.description-line', [
                    'text' => "$floor этаж",
                    'valueToCheck' => $floor,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php if(isset($hidePriceChangeButtonText)): ?>
                <?php echo $__env->make('common.price-change', [
                    'idModifier' => $offerId,
                    'hidePriceChangeButtonText' => $hidePriceChangeButtonText,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('common.price-change', [
                    'idModifier' => $offerId,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="plan-card details">
                <?php if(isset($quarter)): ?>
                    <div class="plan-card description">Срок сдачи: <?php echo e($quarter); ?> квартал <?php echo e($builtYear); ?></div>
                <?php else: ?>
                    <?php if(isset($builtYear)): ?>
                        <div class="plan-card description">Срок сдачи: <?php echo e($builtYear); ?></div>
                    <?php endif; ?>
                <?php endif; ?>
                <?php echo $__env->make('cards.plan.description-line', [
                    'text' => "Тип дома: $material",
                    'valueToCheck' => $material,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('cards.plan.description-line', [
                    'text' => "Отделка: $finishing",
                    'valueToCheck' => $finishing,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <a target="_self" href="/<?php echo e($offerId); ?>" class="common-button bordered">
            Подробнее
        </a>
    </div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/cards/plan/card.blade.php ENDPATH**/ ?>