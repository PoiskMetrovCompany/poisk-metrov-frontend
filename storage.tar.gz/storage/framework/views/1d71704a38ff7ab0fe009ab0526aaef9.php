<div id="chat-message-templates" style="display: none">
    <?php echo $__env->make('chat.messages.sender', [
        'messageText' => '',
        'time' => '',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('chat.messages.reciever', [
        'messageText' => '',
        'recieverName' => '',
        'profilePicUrl' => '',
        'time' => '',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('chat.messages.agent', [
        'time' => '',
        'messageText' => '',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('chat.messages.date', ['date' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('chat.messages.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/message-templates.blade.php ENDPATH**/ ?>