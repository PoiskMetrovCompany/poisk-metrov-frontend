<div id="loader-overlay" class="loader background">
    <img src=<?php echo e(Vite::asset('resources/assets/loader.png')); ?> class="loader rotator"/>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/common/loader.blade.php ENDPATH**/ ?>