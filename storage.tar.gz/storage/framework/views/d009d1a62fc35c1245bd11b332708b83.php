<li <?php if(isset($clientOnly) && $clientOnly == true): ?> clientonly="true" <?php endif; ?>>
    <?php echo $__env->make('icons.icon', ['iconClass' => $icon, 'iconColor' => 'black'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a href="<?php echo e($href); ?>"><?php echo e($optionText); ?></a>
</li>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/parts/user-menu-option.blade.php ENDPATH**/ ?>