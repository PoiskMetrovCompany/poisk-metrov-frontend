<like-button type="button" for="<?php echo e($for ?? 'building'); ?>" like="<?php echo e($isFavorite); ?>" code="<?php echo e($code); ?>">
    <?php echo $__env->make('icons.icon', ['iconClass' => 'action-like', 'iconColor' => 'black'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('common.hint', ['text' => 'Добавить в избранное'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</like-button>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/button/like.blade.php ENDPATH**/ ?>