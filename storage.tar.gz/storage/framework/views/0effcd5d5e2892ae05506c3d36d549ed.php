<script>
    //Is set in getCity script
    let currentCityCached = "st-petersburg";
</script>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/scripts/current-city.blade.php ENDPATH**/ ?>