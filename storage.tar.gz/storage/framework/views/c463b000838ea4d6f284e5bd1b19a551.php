<input <?php if(isset($buttonId)): ?> id="<?php echo e($buttonId); ?>" <?php endif; ?> type="submit"
    class="common-button <?php echo e($subclass ?? ''); ?>" value="<?php echo e($buttonText); ?>" />
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/buttons/submit.blade.php ENDPATH**/ ?>