<mobile-toolbar>
    <?php echo $__env->make('shared.toolbar.button', [
        'icon' => 'home',
        'title' => 'Главная',
        'link' => '/',
        'isCurrentPage' => in_array(Request::path(), $cityService->possibleCityCodes),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('shared.toolbar.button', [
        'icon' => 'buildings',
        'title' => 'Новостройки',
        'link' => '/catalogue',
        'isCurrentPage' => Request::is('*/catalogue'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(Request::is('agent*')): ?>
        <?php echo $__env->make('shared.toolbar.button', [
            'icon' => 'new-request',
            'title' => 'Заявка',
            'link' => '/agent/client/register',
            'isCurrentPage' => Request::is('agent/client/register'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.toolbar.button', [
            'icon' => 'action-like',
            'title' => 'Избранное',
            'link' => '/favorites',
            'isCurrentPage' => Request::is('favorites'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('shared.toolbar.button', [
        'icon' => 'burger',
        'title' => 'Меню',
        'id' => 'mobile-menu-open',
        'isCurrentPage' => false,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</mobile-toolbar>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/shared/toolbar.blade.php ENDPATH**/ ?>