<div class="chat-window date-separator">
    <?php if(!isset($date)): ?>
        <?php
            $date = \Illuminate\Support\Carbon::today();
        ?>
    <?php endif; ?>
    <?php echo e($date); ?>

</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/messages/date.blade.php ENDPATH**/ ?>