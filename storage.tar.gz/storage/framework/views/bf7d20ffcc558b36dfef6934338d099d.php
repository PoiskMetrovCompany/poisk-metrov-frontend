<?php if(isset($defaultOption)): ?>
    <span class="placeholder chosen">
        <?php echo e($defaultOption); ?>

    </span>
<?php else: ?>
    <span class="placeholder">
        <?php if(isset($placeholder)): ?>
            <?php echo e($placeholder); ?>

        <?php endif; ?>
    </span>
<?php endif; ?>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/custom-elements/parts/placeholder.blade.php ENDPATH**/ ?>