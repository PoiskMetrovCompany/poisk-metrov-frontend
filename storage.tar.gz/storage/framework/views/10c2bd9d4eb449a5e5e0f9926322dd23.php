<div class="input-container">
    <fieldset class="input-fieldset">
        <legend class="input-legend"><?php echo e($phoneInputTitle ?? 'Ваш телефон'); ?><span
                class="red-highlight"><?php echo e($required ?? ''); ?></span></legend>
        <div class="input-wrapper">
            <input class="input-text <?php echo e($style ?? ''); ?>" type="tel" id="phone" name="phone"
                placeholder=<?php echo $placeholder ?? '+7'; ?> required <?php if(auth()->guard()->guest()): ?> value=<?php echo $value ?? ''; ?> <?php endif; ?>
                <?php if(auth()->guard()->check()): ?> value=<?php echo $value ?? "'{$user->phone}'"; ?> <?php endif; ?>>
            <img src="<?php echo e(Vite::asset('resources/assets/content/content-error.svg')); ?>" class="error-icon">
            <?php echo $__env->make('icons.icon', ['iconClass' => 'action-close', 'iconColor' => 'grey3'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </fieldset>
    <div class="input-error" id="input-error">Проверьте корректность номера</div>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/inputs/phone.blade.php ENDPATH**/ ?>