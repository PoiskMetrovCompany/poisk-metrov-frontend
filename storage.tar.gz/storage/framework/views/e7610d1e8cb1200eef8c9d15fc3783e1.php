<div class="chat-window header">
    <div class="icon arrow-chevron-right"></div>
    <div class="chat-window header logo">
        <img src="<?php echo e(Vite::asset('resources/assets/site-logo.svg')); ?>" />
    </div>
    <div class="chat-window header text">
        <h6>Чат</h6>
        <p>Мы с вами ежедневно с 10:00 до 21:00</p>
    </div>
    <button class="chat-window header search">
        <div class="icon action-search"></div>
    </button>
</div>
<?php /**PATH /home/poisk-metrov/poisk-metrov-frontend/resources/views/chat/header.blade.php ENDPATH**/ ?>